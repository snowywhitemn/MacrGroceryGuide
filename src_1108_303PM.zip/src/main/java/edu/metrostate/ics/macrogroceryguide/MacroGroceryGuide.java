package edu.metrostate.ics.macrogroceryguide;

import android.app.Application;

public class MacroGroceryGuide extends Application {


}