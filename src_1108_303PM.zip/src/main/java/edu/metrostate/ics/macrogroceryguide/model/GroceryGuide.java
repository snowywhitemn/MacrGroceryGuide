package edu.metrostate.ics.macrogroceryguide.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Implement as a singleton class so we only have one instance ever of the master grocery list
 * @author Group 4
 */

public class GroceryGuide {

    //list of foods
    private List<Food> cart = new ArrayList<>();
    private double calories;
    private double proteinGrams;
    private double fatsGrams;
    private double carbsGrams;
    private static GroceryGuide singleton;

    /**
     * private no argument constructor
     */
    private GroceryGuide(){

    }

    /**
     * Get an instance of the master grocery list. Will create a new instance if it has not
     * already been created.
     * @return GroceryGuide class instance
     */
    public static GroceryGuide getInstance(){
        if(singleton == null){
            singleton = new GroceryGuide();
        }
        return singleton;
    }

    public List<Food> getGroceryList(){
        return cart;
    }
    public void addItem(Food foodItem){
        cart.add(foodItem);
        //update macro nutrient totals to equal all items in cart
        calories = calories + foodItem.getCalories();
        proteinGrams = proteinGrams + foodItem.getProtein();
        fatsGrams = fatsGrams + foodItem.getFat();
        carbsGrams = carbsGrams + foodItem.getCarb();

    }
    public void removeItem(Food foodItem){
            cart.remove(foodItem);

    }
    public double getCalories() {
        return Math.round(calories * 100.00) / 100.00;
    }

    public double getProteinGrams() {
        return Math.round(proteinGrams * 100.00) / 100.00;
    }

    public double getFatsGrams() {
        return Math.round(fatsGrams * 100.00) / 100.00;
    }

    public double getCarbsGrams() {
        return Math.round(carbsGrams * 100.00) / 100.00;
    }


}
