package edu.metrostate.ics.macrogroceryguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import edu.metrostate.ics.macrogroceryguide.R;


public class LoginActivity extends AppCompatActivity {

    private Button login;
    private Button create;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(LoginActivity.this, MainNavActivity.class);
                startActivity(aintent);
            }
        });

        create = findViewById(R.id.create);
        create.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(LoginActivity.this, AccountCreationActivity.class);
                startActivity(bintent);
            }
        });

    }
}

