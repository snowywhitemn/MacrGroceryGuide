package com.example.macronutrientguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class foodCategoryCheckoutActivity extends AppCompatActivity {
    private Button next;
    private Button next2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_category_checkout);

        next = findViewById(R.id.next);
        next2 = findViewById(R.id.next2);
        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(foodCategoryCheckoutActivity.this, CartActivity.class);
                startActivity(aintent);
            }
        });
        next2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(foodCategoryCheckoutActivity.this, CartActivity.class);
                startActivity(aintent);
            }
        });
    }
}


