package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.macronutrientguide.R;

public class bodyInformationActivity extends AppCompatActivity {
    private Button next;
    private ImageButton activityinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_information);

        //set button id
        next = findViewById(R.id.add);
        activityinfo = findViewById(R.id.bodyinformation);

        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(bodyInformationActivity.this, goalSetterActivity.class);
                startActivity(aintent);
            }
        });

        activityinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDia();
            }
        });


    }
    //start info dialog
    public void openDia(){
        bodyInfoFragment body = new bodyInfoFragment();
        body.show(getSupportFragmentManager(), "test");
    }

}

