package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.macronutrientguide.R;

public class mainNavActivity extends AppCompatActivity {

    private Button cart;
    private Button profile;
    private Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_nav);

        cart = findViewById(R.id.add);
        cart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(mainNavActivity.this, cartActivity.class);
                startActivity(aintent);
            }
        });

        profile = findViewById(R.id.nav);
        profile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(mainNavActivity.this, profileActivity.class);
                startActivity(bintent);
            }
        });

        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cintent = new Intent(mainNavActivity.this, loginActivity.class);
                startActivity(cintent);
            }
        });
    }
}