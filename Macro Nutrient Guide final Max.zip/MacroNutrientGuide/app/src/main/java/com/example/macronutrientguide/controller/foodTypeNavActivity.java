package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.macronutrientguide.R;

public class foodTypeNavActivity extends AppCompatActivity {

    private Button back;
    private Button protein;
    private Button fats;
    private Button carb;
    private ImageButton fatinfo;
    private ImageButton proteininfo;
    private ImageButton carbinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_category_checkout);

        back = findViewById(R.id.back);
        protein = findViewById(R.id.protein);
        fats = findViewById(R.id.fats);
        carb = findViewById(R.id.carb);
        fatinfo = findViewById(R.id.fatinformation);
        proteininfo = findViewById(R.id.proteininformation);
        carbinfo = findViewById(R.id.carbinformation);


        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(foodTypeNavActivity.this, cartActivity.class);
                startActivity(aintent);
            }
        });


        protein.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cintent = new Intent(foodTypeNavActivity.this, selectProteinActivity.class);
                startActivity(cintent);
            }
        });
        fats.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent dintent = new Intent(foodTypeNavActivity.this, selectFatActivity.class);
                startActivity(dintent);
            }
        });
        carb.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent eintent = new Intent(foodTypeNavActivity.this, selectCarbActivity.class);
                startActivity(eintent);
            }
        });

        fatinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDiaFat();
            }
        });
        proteininfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDiaPro();
            }
        });
        carbinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDiaCarb();
            }
        });


    }

    //start info dialog fats
    public void openDiaFat(){
        fatFragment body = new fatFragment();
        body.show(getSupportFragmentManager(), "test");
    }

    //start info dialog protein
    public void openDiaPro(){
        proteinFragment body = new proteinFragment();
        body.show(getSupportFragmentManager(), "test");
    }

    //start info dialog carbs
    public void openDiaCarb(){
        carbFragment body = new carbFragment();
        body.show(getSupportFragmentManager(), "test");
    }

}


