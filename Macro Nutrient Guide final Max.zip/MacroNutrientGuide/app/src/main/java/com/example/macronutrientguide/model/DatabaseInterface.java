package com.example.macronutrientguide.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

//sample from https://www.journaldev.com/9438/android-sqlite-database-example-tutorial
//http://www.androidtutorialshub.com/android-login-and-register-with-sqlite-database-tutorial/

public class DatabaseInterface extends SQLiteOpenHelper {


    public static final String TABLE_NAME = "USERS";

    // Table columns
    public static final String UN = "Username";
    public static final String PASS = "Password";
    public static final String FN = "FName";
    public static final String LN = "LName";
    public static final String GENDER = "Gender";
    public static final String AGE = "Age";
    public static final String HEIGHT = "Height";
    public static final String PA = "PhysicalActivityLevel";
    public static final String RMR = "RestingMetabolicRate";
    public static final String TDEE = "TotalDailyEnergyExpenditure";
    public static final String FAT = "fatGrams";
    public static final String PROTEIN = "proteinGrams";
    public static final String CARB = "carbGrams";
    public static final String CAL = "totalCals";
    public static final String GOAL = "Goal";
    public static final String JSONLOCATION = "JSONLocation";

    // Database Information
    static final String DB_NAME = "mnga.DB";

    // database version
    static final int DB_VERSION = 1;

    // Creating table query
    private static final String CREATE_TABLE = "create table " + TABLE_NAME + "(" + UN
            + " TEXT PRIMARY KEY NOT NULL, " + PASS + " TEXT NOT NULL, " + FN + " TEXT, " + LN + " TEXT, " + GENDER + " INTEGER, " + AGE + " INTEGER, " + HEIGHT
            + " INTEGER, " + PA + " INTEGER, "  + RMR + " INTEGER , " + TDEE + " INTEGER, " + FAT + " INTEGER, " + PROTEIN + " INTEGER, " + CARB
            + " INTEGER, " + CAL + " INTEGERL, " + GOAL + " INTEGER, " + JSONLOCATION + " TEXT);";

    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + UN;

    public DatabaseInterface(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
        System.out.print("GfG1");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


        public void createUser(User user) {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues contentValue = new ContentValues();
            contentValue.put(UN, UN);
            contentValue.put(FN, FN);
            contentValue.put(LN, LN);
            contentValue.put(PASS, PASS);

            db.insert(TABLE_NAME, null, contentValue);
            db.close();
        }


    }