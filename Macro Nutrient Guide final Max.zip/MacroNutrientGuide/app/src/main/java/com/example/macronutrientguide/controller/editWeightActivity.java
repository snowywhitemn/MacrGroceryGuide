package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.macronutrientguide.R;

public class editWeightActivity extends AppCompatActivity {
    private Button back;
    private Button confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weight);

        back = findViewById(R.id.back);
        confirm = findViewById(R.id.add);


        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(editWeightActivity.this, profileActivity.class);
                startActivity(aintent);
            }
        });
        confirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(editWeightActivity.this, profileActivity.class);
                startActivity(bintent);
            }
        });
    }
}