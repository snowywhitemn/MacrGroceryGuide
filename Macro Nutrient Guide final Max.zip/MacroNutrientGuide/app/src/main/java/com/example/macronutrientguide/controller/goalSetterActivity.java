package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.macronutrientguide.R;

public class goalSetterActivity extends AppCompatActivity {
    private Button next;
    private ImageButton goalinfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_setter);
        goalinfo = findViewById(R.id.goalInformation);

        next = findViewById(R.id.add);
        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(goalSetterActivity.this, cartActivity.class);
                startActivity(aintent);
            }
        });
        goalinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDia();
            }
        });
    }

    //start info dialog
    public void openDia(){
        goalFragment body = new goalFragment();
        body.show(getSupportFragmentManager(), "test");
    }
}

