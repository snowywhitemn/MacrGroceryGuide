//https://www.youtube.com/watch?v=Bsm-BlXo2SI Simple Dialog with 1 Button - Android Studio Tutorial

package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.macronutrientguide.R;
import com.example.macronutrientguide.model.DatabaseInterface;
import com.example.macronutrientguide.model.User;

public class accountCreationActivity extends AppCompatActivity {
    private Button next;

    EditText fn;
    EditText ln;
    EditText pass;
    EditText un;
    DatabaseInterface dbInterface;
    private User user;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_account_creation);

        //button pointers
        next = findViewById(R.id.add);


        //text fields
        fn = (EditText) findViewById(R.id.fName);
        ln = (EditText) findViewById(R.id.lName);
        pass = (EditText) findViewById(R.id.password);
        un = (EditText) findViewById(R.id.userName);

        //initialize DB
        dbInterface = new DatabaseInterface(this);


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aintent = new Intent(accountCreationActivity.this, bodyInformationActivity.class);

                final String firstName = fn.getText().toString();
                final String lastName = ln.getText().toString();
                final String password = pass.getText().toString();
                final String username = un.getText().toString();

                User user = new User(username, password, firstName, lastName);
                dbInterface.createUser(user);
                startActivity(aintent);

            }
        });


    }



}