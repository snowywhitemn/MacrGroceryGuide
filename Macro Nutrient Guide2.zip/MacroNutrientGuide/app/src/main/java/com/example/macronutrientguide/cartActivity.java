package com.example.macronutrientguide;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class cartActivity extends AppCompatActivity {
    private Button add;
    private Button nav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);


        add = findViewById(R.id.add);
        nav = findViewById(R.id.nav);

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(cartActivity.this, foodTypeNavActivity.class);
                startActivity(aintent);
            }
        });
        nav.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(cartActivity.this, mainNavActivity.class);
                startActivity(bintent);
            }
        });

    }
}

