package com.example.macronutrientguide;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class foodTypeNavActivity extends AppCompatActivity {

    private Button back;
    private Button protein;
    private Button fats;
    private Button carb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_category_checkout);

        back = findViewById(R.id.back);
        protein = findViewById(R.id.protein);
        fats = findViewById(R.id.fats);
        carb = findViewById(R.id.carb);

        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(foodTypeNavActivity.this, cartActivity.class);
                startActivity(aintent);
            }
        });


        protein.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cintent = new Intent(foodTypeNavActivity.this, selectProteinActivity.class);
                startActivity(cintent);
            }
        });
        fats.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent dintent = new Intent(foodTypeNavActivity.this, selectFatActivity.class);
                startActivity(dintent);
            }
        });
        carb.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent eintent = new Intent(foodTypeNavActivity.this, selectCarbActivity.class);
                startActivity(eintent);
            }
        });
    }
}


