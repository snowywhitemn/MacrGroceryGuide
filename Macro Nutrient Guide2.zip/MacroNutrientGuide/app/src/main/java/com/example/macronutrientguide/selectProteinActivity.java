package com.example.macronutrientguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class selectProteinActivity extends AppCompatActivity {
    private Button add;
    private Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_protein);

        add = findViewById(R.id.add);
        back = findViewById(R.id.back);

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(selectProteinActivity.this, cartActivity.class);
                startActivity(aintent);
            }
        });
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(selectProteinActivity.this, cartActivity.class);
                startActivity(bintent);
            }
        });
    }
}