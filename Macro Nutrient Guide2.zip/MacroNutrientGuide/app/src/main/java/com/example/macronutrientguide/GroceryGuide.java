package com.example.macronutrientguide;

import java.util.ArrayList;
import java.util.List;

public class GroceryGuide {

    //list of foods
    private List<Food> cart = new ArrayList<>();

}
