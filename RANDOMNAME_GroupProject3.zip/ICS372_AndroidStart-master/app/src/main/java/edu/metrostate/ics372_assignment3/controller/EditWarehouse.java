package edu.metrostate.ics372_assignment3.controller;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.Warehouse;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

/**
 * Edits the name of the specified warehouse.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class EditWarehouse extends AppCompatActivity {
    private Spinner pickWarehouseEditSpinner;
    private Button selectButton;
    private TextView warehouseIDText;
    private EditText warehouseNameText;
    private Button updateButton;
    private Dialog errSelectWh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_warehouse);

        pickWarehouseEditSpinner = (Spinner) findViewById(R.id.pickWarehouseEditSpinner);
        selectButton = (Button) findViewById(R.id.selectButton);
        updateButton = (Button) findViewById(R.id.updateButton);

        //create array of warehouse id's for Spinner
        ArrayAdapter<String> whEditSpinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                new ArrayList<String>(WarehouseRepository.getInstance().getWhRepo().keySet()));
        //specify layout to use when list of choices appears
        whEditSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //apply the adapter to the spinner
        pickWarehouseEditSpinner.setAdapter(whEditSpinnerAdapter);

        //capture selectButton btn clicks
        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get warehouse of the warehouse id selected in the spinner
                String warehouseIDStr = pickWarehouseEditSpinner.getSelectedItem().toString();
                if(warehouseIDStr == null){
                    //display message that user needs to select a warehouse id to edit
                    errSelectWh = new AlertDialog.Builder(EditWarehouse.this)
                            .setMessage("You must select a warehouse to edit").show();
                }
                final Warehouse warehouseObj = WarehouseRepository.getInstance()
                        .getWarehouse(warehouseIDStr);
                //display warehouse id in warehouseIDText TextView field
                warehouseIDText.setText(warehouseIDStr);
                //display warehouse name in warehouseNameText EditText field
                warehouseNameText.setText(warehouseObj.getName());
                //display toast that user can update the name
                Toast.makeText(EditWarehouse.this, "Update Warehouse Name",
                        Toast.LENGTH_SHORT).show();

                //set onClick action for updateButton
                updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //get text from warehouseNameText
                        String updatedNameStr = warehouseNameText.getText().toString();
                        //update the name on the warehouse object
                        warehouseObj.setName(updatedNameStr);

                        if(updatedNameStr.equals(warehouseObj.getName())){
                            //toast indicating what you updated was successful
                            Toast.makeText(EditWarehouse.this,
                                    "Warehouse name updated", Toast.LENGTH_SHORT).show();

                        }
                    }
                });

            }
        });
    }
}
