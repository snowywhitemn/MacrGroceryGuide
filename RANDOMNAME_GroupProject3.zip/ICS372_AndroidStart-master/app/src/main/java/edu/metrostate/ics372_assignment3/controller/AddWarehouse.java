package edu.metrostate.ics372_assignment3.controller;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

/**
 * Creates a warehouse object and adds it to the warehouse repository map.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class AddWarehouse extends AppCompatActivity {
    private EditText warehouseIDText;
    private EditText warehouseNameText;
    private Button addButton;
    private Dialog addWarehouse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_warehouse);



        //locate addButton in activity_add_warehouse
        addButton = (Button) findViewById(R.id.addWarehouseButton);
        //capture addButton clicks
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //locate warehouseIDText in activity_add_warehouse
                warehouseIDText = (EditText) findViewById(R.id.warehouseIDText);
                //locate warehouseIDText in activity_add_warehouse
                warehouseNameText = (EditText) findViewById(R.id.warehouseNameText);
                String warehouseID = warehouseIDText.getText().toString();
                String warehouseName = warehouseNameText.getText().toString();
                if(!warehouseID.isEmpty()){
                    //create new warehouse adding it to the WarehouseRepository
                    WarehouseRepository.getInstance().addWarehouse(warehouseID, warehouseName);
                    if(WarehouseRepository.getInstance().warehouseExists(warehouseID)){
                        addWarehouse = new AlertDialog.Builder(AddWarehouse.this)
                                .setMessage("Warehouse Added.").show();
                    }

                }else{
                    //dialog saying please enter warehouse name and warehouse id
                    addWarehouse= new AlertDialog.Builder(AddWarehouse.this)
                            .setMessage("Please enter both a warehouse name and a warehouse " +
                                    "id to create a warehouse.").show();
                }

            }
        });
    }
}
