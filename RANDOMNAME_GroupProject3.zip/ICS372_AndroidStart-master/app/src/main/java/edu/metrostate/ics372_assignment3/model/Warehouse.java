package edu.metrostate.ics372_assignment3.model;
import java.util.ArrayList;
import java.util.List;
/**
 * Class represents a warehouse object
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class Warehouse {
    private String warehouseID;
    private String name;
    private boolean freightReceipt;
    private List<Shipment> listOfShipments;
    private List<Shipment> shippedShipments;

    /**
     * Default no argument constructor that initializes a warehouses list of shipments and shipped
     * shipments.
     */
    public Warehouse() {
        listOfShipments = new ArrayList<>();
        shippedShipments = new ArrayList<>();
    }


    /**
     * Constructor to create a new warehouse object with a name and warehouseID. Initializes the
     * warehouses list of shipments and enables freight receipt.
     *
     * @param warehouseID
     * @param name
     */
    public Warehouse(String warehouseID, String name) {

        this.warehouseID = warehouseID;
        this.name = name;
        //initialize list of shipments
        listOfShipments = new ArrayList<Shipment>();
        //initializes list of shipped shipments
        shippedShipments = new ArrayList<>();
        //enable freight receipt
        enableFreightReceipt();
    }

    /**
     * Get warehouse ID of the warehouse.
     *
     * @return warehouseID
     */
    public String getWarehouseID() {
        return warehouseID;
    }

    /**
     * Gets the name of the warehouse object.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the list of shipments as an arraylist for the warehouse
     *
     * @return list of shipments for the warehouse
     */
    public List<Shipment> getListOfShipments() {
        return listOfShipments;
    }
    /**
     * Returns the list of shipped shipments as an arraylist.
     *
     * @return list of shipped shipments for the warehouse
     */
    public List<Shipment> getShippedShipments() {
        return shippedShipments;
    }

    /**
     * Sets the name of the warehouse object. This should be used if you are changing the name of a warehouse.
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the freight receipt value to true, indicating that the warehouse can receive shipments.
     */
    public void enableFreightReceipt() {
        this.freightReceipt = true;
    }

    /**
     * Returns true if the warehouse has freight receipt enabled. Returns false if the warehouse has freight receipt disabled.
     *
     * @return freightReceipt
     */
    public boolean isFreightReceipt() {
        return this.freightReceipt;
    }

    /**
     * Sets freight receipt value to false, indicating that the warehouse is not able to receive anymore shipments.
     */
    public void disableFreightReceipt() {
        this.freightReceipt = false;
    }

    /**
     * Adds incoming shipment into listOfShipments
     *
     * @param shipment
     */
    public void addIncomingShipment(Shipment shipment) {
        //if freight receipt is allowed then add the shipment
        if (isFreightReceipt()) {
            //add shipment to list of shipments
            listOfShipments.add(shipment);
        } else {
            //should probably handle this differently
            System.out.println("Freight Receipt is not enabled for this warehouse" + shipment.getWarehouseID() + "/n"
                    + "Shipment was not added" + shipment.getShipmentID());
        }

    }
    /**
     * Adds leaving shipment to list of shipped shipments.
     */
    public void updateShippedShipments(Shipment shipment){
        //remove from list of shipments
        deleteShipment(shipment);
        //add to list of shipped shipments
        shippedShipments.add(shipment);

    }
    /**
     * Removes shipment from list of shipments.
     */
    public void deleteShipment(Shipment shipment){
        listOfShipments.remove(shipment);
    }

    /**
     * Gets a list of all shipment ids that are currently at the warehouse
     * @return list of shipment ids
     */
    public List<String> getListOfShipID(){
        List<String> listOfShipID = new ArrayList<>();
        for(Shipment shipment : this.listOfShipments){
            listOfShipID.add(shipment.getShipmentID());
        }
        return listOfShipID;
    }
    public Shipment getShipment(String shipmentID){
        Shipment shipment = null;
        for (Shipment s: this.listOfShipments) {
            if(s.getShipmentID().equals(shipmentID)){
                shipment = s;
            }
        }
        return shipment;
    }




    /**
     * Custom string representation of a warehouse.
     * @return
     */
    @Override
    public String toString() {
        return "Warehouse{" +
                "warehouseID='" + warehouseID + '\'' +
                ", name='" + name + '\'' +
                ", freightReceipt=" + freightReceipt +
                '}';
    }
}
