package edu.metrostate.ics372_assignment3.controller;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.WarehouseApplication;
import edu.metrostate.ics372_assignment3.model.ImportShipmentsJSON;
import edu.metrostate.ics372_assignment3.model.StateSave;

/**
 * Main activity class. Represents the main screen when the application starts. Outline given by
 * Professor Carlson.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class MainActivity extends AppCompatActivity {

    private static final int WRITE_STORAGE_PERMISSION_REQUEST = 5;
    private Button addShipFromFileButton;
    private Button addShipManuallyButton;
    private Button viewShipFromWarehouseButton;
    private Button shipShipmentButton;
    private Button viewWarehousesButton;
    private Button addWarehouseButton;
    private Button editWarehouseButton;
    private Button enableDisableFreightButton;
    private Button exitButton;


    private WarehouseApplication application;


    /**
     * Creates the view for the application
     *
     * @param savedInstanceState saved state information for the activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        application = (WarehouseApplication) getApplication();

        //locate the exit button from file button in activity_main.xml
        exitButton = (Button) findViewById(R.id.exit);
        //capture exitButton clicks
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                //Saves state of the program (warehouses and shipments) and closes the app
                StateSave.save();
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finish();
                System.exit(0);
            }
        });

        //locate add shipments from file button in activity_main.xml
        addShipFromFileButton = (Button) findViewById(R.id.add_shipment_from_file_btn);
        //capture add_shipment_from_file_btn clicks
        addShipFromFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start AddShipFromFileActivity.class
                Intent addShipFromFileIntent = new Intent(MainActivity.this, AddShipFromFile.class);
                MainActivity.this.startActivity(addShipFromFileIntent);
            }
        });

        //locate add shipment manually button in activity_main.xml
        addShipManuallyButton = (Button) findViewById(R.id.add_ship_manually_btn);
        //capture add_ship_manually_btn clicks
        addShipManuallyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start AddShipManually.class
                Intent addShipManually = new Intent(MainActivity.this, AddShipManually.class);
                MainActivity.this.startActivity(addShipManually);

            }
        });

        //locate view shipments from warehouse button in activity_main.xml
        viewShipFromWarehouseButton = (Button) findViewById(R.id.view_ship_from_warehosue_btn);
        //capture view_ship_from_warehouse_btn clicks
        viewShipFromWarehouseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start ViewShipFromWarehouse.class
                Intent viewShipFromWarehouse = new Intent(MainActivity.this, ViewShipFromWarehouse.class);
                MainActivity.this.startActivity(viewShipFromWarehouse);
            }
        });

        //locate ship shipment button in activity_main.xml
        shipShipmentButton = (Button) findViewById(R.id.ship_shipment_btn);
        //capture ship_shipment_btn clicks
        shipShipmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start ShipShipment.class
                Intent shipShipment = new Intent(MainActivity.this, ShipShipment.class);
                MainActivity.this.startActivity(shipShipment);
            }
        });



        //locate view warehouses button in activity_main.xml
        viewWarehousesButton = (Button) findViewById(R.id.view_warehouses_btn);
        //capture view_warehouse_btn clicks
        viewWarehousesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start ViewWarehouse.class
                Intent viewWarehouses = new Intent(MainActivity.this, ViewWarehouses.class);
                MainActivity.this.startActivity(viewWarehouses);
            }
        });

        //locate add warehouses button in activity_main.xml
        addWarehouseButton = (Button) findViewById(R.id.add_warehouse_btn);
        //capture view_warehouse_btn clicks
        addWarehouseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start AddWarehouse.class
                Intent addWarehouse = new Intent(MainActivity.this, AddWarehouse.class);
                MainActivity.this.startActivity(addWarehouse);
            }
        });

        //locate edit warehouses button in activity_main.xml
        editWarehouseButton = (Button) findViewById(R.id.edit_warehouse_btn);
        //capture view_warehouse_btn clicks
        editWarehouseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start EditWarehouse.class
                Intent EditWarehouse = new Intent(MainActivity.this, edu.metrostate.ics372_assignment3.controller.EditWarehouse.class);
                MainActivity.this.startActivity(EditWarehouse);
            }
        });

        //locate enable / disable fright receipt button in activity_main.xml
        enableDisableFreightButton = (Button) findViewById(R.id.enable_disable_freight_btn);
        //capture view_warehouse_btn clicks
        enableDisableFreightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //start EnableDisableReceipt.class
                Intent EnableDisableFreight = new Intent(MainActivity.this, edu.metrostate.ics372_assignment3.controller.EnableDisableFreight.class);
                MainActivity.this.startActivity(EnableDisableFreight);
            }
        });




                //  Check Storage Permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    WRITE_STORAGE_PERMISSION_REQUEST);
        }
        // Initial load of saved shipments from previous sessions //
        File savedFile = new File("/sdcard/WarehouseStateSave/WarehouseStateSave.json");
        try {
            FileReader savedFileJSON = new FileReader(savedFile);
            JSONParser jsonParser = new JSONParser();
            Object obj = jsonParser.parse(savedFileJSON);
            JSONObject jsonObject = (JSONObject) obj;
            if(savedFile.exists() && jsonObject.size() != 0) {
                ImportShipmentsJSON.readInShipments("/sdcard/WarehouseStateSave/WarehouseStateSave.json");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }




        // Initial load of saved shipments from previous sessions //


    }


    /**
     * Indicates when the user has responded to a permission request
     *
     * @param requestCode  The request code
     * @param permissions  The permissions requested
     * @param grantResults The result
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case WRITE_STORAGE_PERMISSION_REQUEST: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, "Permission required, closing application", Toast.LENGTH_LONG).show();
                    finish();
                }
                return;
            }
        }
    }

}
