package edu.metrostate.ics372_assignment3.model;

/**
 * Ships a shipment, moving it from one warehouse to another warehouse.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class ShipShipments {
    private Shipment shipment;
    private Warehouse currentWarehouse;
    private Warehouse receivingWarehouse;

    public ShipShipments(Shipment shipment, Warehouse receivingWarehouse) {
        this.shipment = shipment;
        this.receivingWarehouse = receivingWarehouse;
        this.currentWarehouse = WarehouseRepository.getInstance().getWarehouse(shipment.getWarehouseID());

    }

    /**
     * Ships a shipment from current warehouse to receiving warehouse.
     */
    public void ship(){
        //remove shipment from current warehouse list of shipments and
        //add to current warehouse shippedShipments list
        currentWarehouse.updateShippedShipments(shipment);
        //update shipment with new warehouse ID
        shipment.setWarehouseID(receivingWarehouse.getWarehouseID());
        //add shipment to receiving warehouse listOfShipments
        receivingWarehouse.addIncomingShipment(shipment);

    }


}
