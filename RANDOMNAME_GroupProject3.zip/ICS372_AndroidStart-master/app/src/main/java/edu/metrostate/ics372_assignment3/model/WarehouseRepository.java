package edu.metrostate.ics372_assignment3.model;
import java.util.HashMap;
import java.util.Map;
/**
 * Singleton class to manage the different warehouse objects.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class WarehouseRepository {
    private Map<String, Warehouse> whRepo = new HashMap<>();
    private static WarehouseRepository singleton;

    private WarehouseRepository() {

    }

    /**
     * Get an instance of the warehouse repository. Will create a new instance if one has not already been created.
     *
     * @return warehouse repository class instance
     */
    public static WarehouseRepository getInstance() {
        if (singleton == null) {
            singleton = new WarehouseRepository();
        }
        return singleton;
    }

    /**
     * Get the warehouse object from the map of the warehouse repository.
     * @param warehouseID
     * @return warehouse object instance
     */
    public Warehouse getWarehouse(String warehouseID){

        if(warehouseExists(warehouseID)){
            return whRepo.get(warehouseID);
        }

        return null;

    }

    /**
     * Get the Warehouse Repository Map, which will allow you to get an instance of the warehouse
     * object by providing the warehouse id
     * @return warehouse repository
     */
    public Map<String, Warehouse> getWhRepo() {
        return whRepo;
    }

    /**
     * Checks to see if the warehouse already exists in the repository
     * @param warehouseID
     * @return boolean value indicating if the warehouse exists in the repository or not
     */
    public boolean warehouseExists(String warehouseID){
        boolean exists = false;
        if(whRepo.containsKey(warehouseID)){
            exists = true;
        }
        return exists;
    }

    /**
     * Create a new warehouse and add to the repository
     * @param warehouseID
     * @param name
     */
    public void addWarehouse(String warehouseID, String name){
        Warehouse warehouse = new Warehouse(warehouseID, name);
        whRepo.put(warehouseID, warehouse);
    }
}
