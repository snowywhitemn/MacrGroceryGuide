package edu.metrostate.ics372_assignment3;

import android.app.Application;

public class WarehouseApplication extends Application {
}
