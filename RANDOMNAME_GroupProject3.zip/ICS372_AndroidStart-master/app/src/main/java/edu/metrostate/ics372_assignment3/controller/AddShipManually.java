package edu.metrostate.ics372_assignment3.controller;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.Shipment;
import edu.metrostate.ics372_assignment3.model.Warehouse;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

/**
 * Adds a shipment to the specified warehouses list of shipments.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class AddShipManually extends AppCompatActivity {

    private Spinner warehouseIDSpinner;
    private Spinner shipMethodSpinner;
    private EditText shipmentIDText;
    private EditText weightText;
    private Button addButton;
    private Dialog errFreightReceipt;
    private Dialog shipAdded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ship_manually);

        warehouseIDSpinner = (Spinner) findViewById(R.id.shipManWhIDSpinner);
        shipMethodSpinner = (Spinner) findViewById(R.id.shipMethodSpinner);
        shipmentIDText = (EditText) findViewById(R.id.shipIDText);
        weightText = (EditText) findViewById(R.id.weightDecimalText);
        addButton = (Button) findViewById(R.id.addShipButton);


        //create array of warehouse id's for Spinner
        ArrayAdapter<String> warehouseIDSpinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                new ArrayList<String>(WarehouseRepository.getInstance().getWhRepo().keySet()));
        //specify layout to use when list of choices appears
        warehouseIDSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //apply the adapter to the spinner
        warehouseIDSpinner.setAdapter(warehouseIDSpinnerAdapter);

        //create array of shipment methods for shipMethodSpinner;
        ArrayAdapter<Shipment.ShipmentMethod> shipMethodSpinnerAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                     new ArrayList<Shipment.ShipmentMethod>(Arrays.asList(Shipment.ShipmentMethod.values())));
        //specify layout to use when list of choices appears
        shipMethodSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //apply the adapter to the spinner
        shipMethodSpinner.setAdapter(shipMethodSpinnerAdapter);

        //set on click action for addShipButton
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get value from warehouseIDSpinner
                String warehouseIDStr = warehouseIDSpinner.getSelectedItem().toString();
                if(WarehouseRepository.getInstance().getWarehouse(warehouseIDStr).isFreightReceipt()){
                   Warehouse warehouseObj = WarehouseRepository.getInstance().getWarehouse(warehouseIDStr);
                    //get value from shipMethodSpinner and convert into Enum
                    String shipMethodStr = shipMethodSpinner.getSelectedItem().toString();
                    //get value from shipmentIDText
                    String shipIDStr = shipmentIDText.getText().toString();
                    //get value from weightText and convert from string to double to Long
                    Double weightDec = Double.parseDouble(weightText.getText().toString());
                    //get Date value
                    Date receiptDate = new Date(System.currentTimeMillis());
                    //create shipment and add to warehouses list of shipments if warehouse freight receipt is enabled
                    Shipment shipment = new
                            Shipment(warehouseIDStr, shipMethodStr, shipIDStr, weightDec, receiptDate);
                    //add shipment to warehouse shipments list
                    warehouseObj.addIncomingShipment(shipment);
                    //if shipment was successfully added notify the user with dialog box
                    if(shipment.getShipmentID().equals(warehouseObj.getShipment(shipment.getShipmentID()).getShipmentID())){
                        shipAdded = new AlertDialog.Builder(AddShipManually.this)
                                .setMessage("Shipment Added.").show();
                    }

                }else{
                    //if freight receipt not enabled for the warehouse send dialog message
                    errFreightReceipt = new AlertDialog.Builder(AddShipManually.this)
                            .setMessage("Freight receipt is NOT enabled for this warehouse.").show();
                }




            }
        });


    }
}
