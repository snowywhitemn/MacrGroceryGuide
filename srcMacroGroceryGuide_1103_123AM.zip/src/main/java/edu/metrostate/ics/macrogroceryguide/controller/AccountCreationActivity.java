package edu.metrostate.ics.macrogroceryguide.controller;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import edu.metrostate.ics.macrogroceryguide.R;
import edu.metrostate.ics.macrogroceryguide.model.User;

public class AccountCreationActivity extends AppCompatActivity {
    private Button next;
    private EditText fn;
    private EditText ln;
    private EditText pass;
    private EditText un;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        next = (Button)findViewById(R.id.nextButton);
        fn   = (EditText)findViewById(R.id.fName);
        ln   = (EditText)findViewById(R.id.lName);
        pass   = (EditText)findViewById(R.id.password);
        un   = (EditText)findViewById(R.id.userName);



        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                String firstName = fn.getText().toString();
                String lastName = ln.getText().toString();
                String password = pass.getText().toString();
                String username = un.getText().toString();

                //create the user object

                User.getInstance().createUser(firstName, lastName, username, password);
                Log.d("user created",  User.getInstance().toString());
                Log.i("user created", User.getInstance().toString());

                startActivity(new Intent(AccountCreationActivity.this, BodyInformationActivity.class));


            }
        });



    }
}