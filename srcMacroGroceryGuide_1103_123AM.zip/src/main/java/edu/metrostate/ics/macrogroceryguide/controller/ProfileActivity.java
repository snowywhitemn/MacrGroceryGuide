package edu.metrostate.ics.macrogroceryguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import edu.metrostate.ics.macrogroceryguide.R;
import edu.metrostate.ics.macrogroceryguide.model.User;

public class ProfileActivity extends AppCompatActivity {
    private Button editProfile;
    private Button editWeight;
    private Button nav;
    private TextView nameTextView;
    private TextView calTotals;
    private TextView protTotals;
    private TextView fatsTotals;
    private TextView carbsTotals;
    private TextView subCalTotals;
    private TextView subProtTotals;
    private TextView subFatsTotals;
    private TextView subCarbsTotals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //find macro totals text view
        calTotals = findViewById(R.id.caloriesTotalTextView);
        protTotals = findViewById(R.id.proteinTotalTextView);
        fatsTotals = findViewById(R.id.fatsTotalTextView);
        carbsTotals = findViewById(R.id.carbsTotalTextView);

        //set text for macro totals text view
        calTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getTotalCals()));
        protTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getTotalProteinGrams()));
        fatsTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getTotalFatGrams()));
        carbsTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getTotalCarbGrams()));

        //find running macro totals text views
        subCalTotals = findViewById(R.id.subCaloriesTotalTextView);
        subProtTotals = findViewById(R.id.subProteinTotalTextView);
        subFatsTotals = findViewById(R.id.subFatsTotalTextView);
        subCarbsTotals = findViewById(R.id.subCarbsTotalsTextView);

        //set text for runnning totals
        subCalTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getSubTotalCals()));
        subProtTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getSubTotalProteinGrams()));
        subFatsTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getSubTotalFatGrams()));
        subCarbsTotals.setText(String.valueOf(User.getInstance().getMacroTotals().getSubTotalCarbGrams()));

        nameTextView = findViewById(R.id.nameTextView);
        nameTextView.setText(User.getInstance().getFirstName());

        editProfile = findViewById(R.id.editProfile);
        editProfile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(ProfileActivity.this, EditProfileActivity.class);
                startActivity(aintent);
            }
        });

        editWeight = findViewById(R.id.weightEditText);
        editWeight.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(ProfileActivity.this, EditAssessmentActivity.class);
                startActivity(bintent);
            }
        });

        nav = findViewById(R.id.nav);
        nav.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cintent = new Intent(ProfileActivity.this, MainNavActivity.class);
                startActivity(cintent);
            }
        });
    }

}
