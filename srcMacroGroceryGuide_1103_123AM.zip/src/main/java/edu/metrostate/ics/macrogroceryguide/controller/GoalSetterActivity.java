package edu.metrostate.ics.macrogroceryguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import edu.metrostate.ics.macrogroceryguide.R;
import edu.metrostate.ics.macrogroceryguide.model.MacroTotals;
import edu.metrostate.ics.macrogroceryguide.model.User;

public class GoalSetterActivity extends AppCompatActivity {
    private Button next;
    private int goalChoice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_setter);

        //locate RadioButtons
        RadioButton lose = (RadioButton)findViewById(R.id.loseRadioButton);
        RadioButton maintain = (RadioButton)findViewById(R.id.maintainRadioButton);
        RadioButton gain = (RadioButton)findViewById(R.id.gainRadioButton);

        lose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((RadioButton) v).isChecked();
                if(checked){
                    goalChoice = 0;
                }
            }
        });
        maintain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((RadioButton) v).isChecked();
                if(checked){
                    goalChoice = 1;
                }
            }
        });
        gain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((RadioButton) v).isChecked();
                if(checked){
                    goalChoice = 2;
                }
            }
        });


        //locate next button
        next = findViewById(R.id.nextButton);
        //capture next button clicks
        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //get tdee value and goal to calculate macro totals
                MacroTotals mTotals = new MacroTotals(User.getInstance()
                        .getAssesment().getTdeeResult(), goalChoice);
                Log.d("Macro Totals", mTotals.toString());
                //set Users Macro Totals
                User.getInstance().setMacroTotals(mTotals);
                Log.d("User mtotals", User.getInstance().getMacroTotals().toString());

                Intent aintent = new Intent(GoalSetterActivity.this, CartActivity.class);
                startActivity(aintent);
            }
        });

    }
}

