package edu.metrostate.ics.macrogroceryguide.model;

/**
 * Class to store user assessment.
 * Sedentary = BMR x 1.2 (little or no exercise, desk job)
 * Lightly active = BMR x 1.375 (light exercise/ sports 1-3 days/week)
 * Moderately active = BMR x 1.55 (moderate exercise/ sports 6-7 days/week)
 * Very active = BMR x 1.725 (hard exercise every day, or exercising 2 xs/day)
 */

public class Assessment {


    private double pal; //physical activity level
    private User.Gender gen;
    private int age; //in years
    private double height; //in cm
    private double weight; //in kg
    private double rmrResult;
    private double tdeeResult;


    public Assessment(User.Gender gen, int age, double height, double weight, double pal){

        this.gen = gen;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.pal = pal;
        calculateRMR();
        calcTDEE();
    }


    public double getPal() {
        return pal;
    }


    public int getAge() {
        return age;
    }

    public double getHeight() {
        return height;
    }

    public double getWeight() {
        return weight;
    }

    public double getRmrResult() {
        return rmrResult;
    }

    public double getTdeeResult() {
        return tdeeResult;
    }

    /**
     * Calculates RMR (Resting metabolic rate) using Mifflin-St.Jeor equation
     *
     * @precondition weight in kg, height in cm and age in years
     */
    public void calculateRMR() {
        if (this.gen == User.Gender.F) {
            //Mifflin-St.Jeor equation for female
            this.rmrResult = ((((10 * weight) + (6.25 * height)) - (5 * age)) - 161);

        } else {
            //Mifflin-St.Jeor equation for male
            this.rmrResult = ((((10 * weight) + (6.25 * height)) - (5 * age)) + 5);

        }
    }
    /**
     * Calculate TDEE(Total Daily Energy Expenditure) using RMR X PAL (Physical Activity Level).
     * The TDEE will be the calories needed to maintain weight.
     * @precondition rmr has to be already calculated
     */
    public void calcTDEE(){
        this.tdeeResult = rmrResult * pal;
    }


}
