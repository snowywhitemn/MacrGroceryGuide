package edu.metrostate.ics.macrogroceryguide.controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import edu.metrostate.ics.macrogroceryguide.R;
import edu.metrostate.ics.macrogroceryguide.adapter.FoodRecyclerAdapter;
import edu.metrostate.ics.macrogroceryguide.model.Food;
import edu.metrostate.ics.macrogroceryguide.model.GroceryGuide;

public class CartActivity extends AppCompatActivity implements FoodRecyclerAdapter.OnItemClickListener {
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;
    private RecyclerView.Adapter cartAdapter;
    private FloatingActionButton backToMainMenuFAB;
    private FloatingActionButton addItemsToCartFAB;
    private List<Food> masterGroceryList = new ArrayList<>();
    private Food groceryItem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_cart);

        //get grocery list to display in the cart
        masterGroceryList = GroceryGuide.getInstance().getGroceryList();

        //once page opens recycler view should populate with food objects
        recyclerView = findViewById(R.id.recycleViewCart);
        cartAdapter = new FoodRecyclerAdapter(getApplicationContext(), masterGroceryList,
                this);
        linearLayoutManager = new LinearLayoutManager(this);

        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                linearLayoutManager.getOrientation());
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(cartAdapter);


        //locate buttons
        backToMainMenuFAB = findViewById(R.id.backToMainMenuFAB);
        addItemsToCartFAB = findViewById(R.id.addItemsToCartFAB);

        addItemsToCartFAB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(CartActivity.this,
                        FoodTypeNavActivity.class);
                startActivity(aintent);
            }
        });
        backToMainMenuFAB.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(CartActivity.this, MainNavActivity.class);
                startActivity(bintent);
            }
        });

    }

    @Override
    public void onItemClick(int position) {
        //pop up dialog to prompt for removal of item
        //groceryItem = masterGroceryList.get(position);
        //GroceryGuide.getInstance().removeItem(groceryItem);
    }
}

