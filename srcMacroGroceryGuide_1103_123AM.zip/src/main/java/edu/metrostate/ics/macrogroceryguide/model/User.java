package edu.metrostate.ics.macrogroceryguide.model;

/**
 * User is the person using the application. Certain criteria needs to be collected before
 * other features of the app will work. This class holds that information gender, age, height,
 * weight.
 */
public class User {
    public enum Gender {
        M, F;

    }

    private Assessment assessment;
    private MacroTotals macroTotals;
    private Gender gen;
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    private static User singleton;


    /**
     * Default no argument constructor.
     */
    private User(){

    }

    /**
     * Get an instance of the User. Will create a new instance if one has not already been created.
     * @return user class instance
     */
    public static User getInstance(){
        if(singleton == null){
             singleton = new User();
        }
        return singleton;
    }

    public void createUser(String firstName, String lastName, String username, String password) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Gender getGen() {
        return gen;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Assessment getAssesment() {
        return assessment;
    }

    public void setAssesment(Assessment assesment) {
        this.assessment = assesment;
    }

    public MacroTotals getMacroTotals() {
        return macroTotals;
    }

    public void setMacroTotals(MacroTotals macroTotals) {
        this.macroTotals = macroTotals;
    }

}
