package edu.metrostate.ics.macrogroceryguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

import edu.metrostate.ics.macrogroceryguide.R;
import edu.metrostate.ics.macrogroceryguide.model.User;

public class EditProfileActivity extends AppCompatActivity {
    private Button back;
    private Button confirm;
    private EditText fName;
    private EditText lName;
    private EditText username;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        //load current information into boxes
        //do not save unless all boxes have been filled in
        fName = (EditText)findViewById(R.id.fName);
        lName = (EditText)findViewById(R.id.lName);
        username = (EditText)findViewById(R.id.userName);
        password = (EditText)findViewById(R.id.password);

        fName.setText(User.getInstance().getFirstName());
        lName.setText(User.getInstance().getLastName());
        username.setText(User.getInstance().getUsername());
        password.setText(User.getInstance().getPassword());

        //locate buttons
        back = findViewById(R.id.backButton);
        confirm = findViewById(R.id.nextButton);
        //capture button clicks
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(EditProfileActivity.this, ProfileActivity.class);
                startActivity(aintent);
            }
        });
        confirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //set all values in user unless null then do not change
                if(fName.getText().toString() != null && !fName.getText().toString().isEmpty()){

                    String firstNameStr = fName.getText().toString();
                    User.getInstance().setFirstName(firstNameStr);
                }
                if(lName.getText().toString() != null && !lName.getText().toString().isEmpty()){
                    String lastNameStr = lName.getText().toString();
                    User.getInstance().setLastName(lastNameStr);
                }
                if(username.getText().toString() != null && !username.getText().toString().isEmpty()){
                    String uNameStr = username.getText().toString();
                    User.getInstance().setUsername(uNameStr);
                }
                if(password.getText().toString() != null && !password.getText().toString().isEmpty()){
                    String passStr = password.getText().toString();
                    User.getInstance().setPassword(passStr);
                }

                Intent bintent = new Intent(EditProfileActivity.this, ProfileActivity.class);
                startActivity(bintent);
            }
        });
    }
}
