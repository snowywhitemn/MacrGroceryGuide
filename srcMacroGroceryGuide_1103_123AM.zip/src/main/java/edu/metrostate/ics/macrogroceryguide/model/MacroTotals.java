package edu.metrostate.ics.macrogroceryguide.model;

/**
 *
 */
public class MacroTotals {
    /**
     * Macro Percentages:
     * Protein 30%
     * Carbs 50%
     * Fats 20%
     */
    
    private double totalFatGrams;
    private double totalProteinGrams;
    private double totalCarbGrams;
    private double totalCals;

    private double subTotalFatGrams;
    private double subTotalProteinGrams;
    private double subTotalCarbGrams;
    private double subTotalCals;

    
    private final double FAT_PERCENT = 0.2; 
    private final double PROTEIN_PERCENT = 0.3;
    private final double CARB_PERCENT = 0.5; 
    
    private final int FOUR_CAL_PER_GRAM = 4; 
    private final int NINE_CAL_PER_GRAM = 9;
    private final int WEEKLY_MULTIPLIER = 7;

    public MacroTotals(double tdee, int goal){


        if(goal == 0){
            this.totalCals = ((tdee - 500) * WEEKLY_MULTIPLIER);
        }else if(goal == 1){
            this.totalCals = (tdee * WEEKLY_MULTIPLIER);
        }else{
            this.totalCals = ((tdee + 500) * WEEKLY_MULTIPLIER);
        }

        this.totalFatGrams = (calcFatGrams() * WEEKLY_MULTIPLIER);
        this.totalProteinGrams = (calcProteinGrams() * WEEKLY_MULTIPLIER);
        this.totalCarbGrams = (calcCarbGrams() * WEEKLY_MULTIPLIER);

        subTotalFatGrams = 0.0;
        subTotalProteinGrams = 0.0;
        subTotalCarbGrams = 0.0;
        subTotalCals = 0.0;

    }

    /**
     * Calculates the amount in grams of fat the user should have daily based on their TDEE
     * (total daily energy expenditure)
     * @precondition TDEE has been calculated
     * @return fatGrams
     */
    private double calcFatGrams() {
        return ((totalCals * FAT_PERCENT) / NINE_CAL_PER_GRAM);
    }

    /**
     * Calculates the amount in grams of protein the user should have daily based on their TDEE
     * @return proteinGrams
     */
    private double calcProteinGrams() {
        return ((totalCals * PROTEIN_PERCENT) / FOUR_CAL_PER_GRAM);
    }

    /**
     * Calculated the amount in grams of carbs the user should have daily based on their TDEE
     * @return
     */
    private double calcCarbGrams() {
        return ((totalCals * CARB_PERCENT) / FOUR_CAL_PER_GRAM);
    }

    /**
     * Updates the running total of fat grams. Value is updates when user adds an item to the cart.
     * @param grams
     * @return updated running total of fat grams
     */
    public double updateSubTotalFatGrams(double grams){
        return (this.subTotalFatGrams + grams);
    }
    /**
     * Updates the running total of protein grams. Value is updates when user adds an item to the cart.
     * @param grams
     * @return updated running total of protein grams
     */
    public double updateSubTotalProteinGrams(double grams){
        return (this.subTotalProteinGrams + grams);
    }
    /**
     * Updates the running total of carb grams. Value is updates when user adds an item to the cart.
     * @param grams
     * @return updated running total of carb grams
     */
    public double updateSubTotalCarbGrams(double grams){
        return (this.subTotalCarbGrams + grams);
    }
    /**
     * Updates the running total of calories. Value is updates when user adds an item to the cart.
     * @param cals
     * @return updated running total of calories
     */
    public double updateSubTotalCals(double cals){
        return (subTotalCals + cals);
    }

    public double getTotalFatGrams() {
        return totalFatGrams;
    }

    public double getTotalProteinGrams() {
        return totalProteinGrams;
    }

    public double getTotalCarbGrams() {
        return totalCarbGrams;
    }

    public double getTotalCals() {
        return totalCals;
    }

    public double getSubTotalFatGrams() {
        return subTotalFatGrams;
    }

    public double getSubTotalProteinGrams() {
        return subTotalProteinGrams;
    }

    public double getSubTotalCarbGrams() {
        return subTotalCarbGrams;
    }

    public double getSubTotalCals() {
        return subTotalCals;
    }

    @Override
    public String toString() {
        return "MacroTotals{" +
                "fatGrams=" + totalFatGrams +
                ", proteinGrams=" + totalProteinGrams +
                ", carbGrams=" + totalCarbGrams +
                ", totalCals=" + totalCals +
                ", FAT_PERCENT=" + FAT_PERCENT +
                ", PROTEIN_PERCENT=" + PROTEIN_PERCENT +
                ", CARB_PERCENT=" + CARB_PERCENT +
                '}';
    }
}
