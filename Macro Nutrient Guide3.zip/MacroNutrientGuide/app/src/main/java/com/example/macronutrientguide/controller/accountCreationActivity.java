package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.macronutrientguide.R;
import com.example.macronutrientguide.model.User;

public class accountCreationActivity extends AppCompatActivity {
    private Button next;
    EditText fn;
    EditText ln;
    EditText pass;
    EditText un;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        next = findViewById(R.id.add);
        fn   = (EditText)findViewById(R.id.fName);
        ln   = (EditText)findViewById(R.id.lName);
        pass   = (EditText)findViewById(R.id.password);
        un   = (EditText)findViewById(R.id.userName);

        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(accountCreationActivity.this, bodyInformationActivity.class);
                startActivity(aintent);
                String firstName = fn.getText().toString();
                String lastName = ln.getText().toString();
                String password = pass.getText().toString();
                String username = un.getText().toString();

                User makeUser = new User(username, password, firstName, lastName);

            }
        });


    }
}