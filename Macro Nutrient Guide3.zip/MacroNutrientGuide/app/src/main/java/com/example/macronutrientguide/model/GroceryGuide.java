package com.example.macronutrientguide.model;

import java.util.ArrayList;
import java.util.List;

public class GroceryGuide {

    //list of foods
    private List<Food> cart = new ArrayList<>();

}
