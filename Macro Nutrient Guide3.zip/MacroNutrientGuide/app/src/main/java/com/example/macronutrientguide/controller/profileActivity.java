package com.example.macronutrientguide.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.macronutrientguide.R;

public class profileActivity extends AppCompatActivity {
    private Button editProfile;
    private Button editWeight;
    private Button nav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        editProfile = findViewById(R.id.editProfile);
        editProfile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent aintent = new Intent(profileActivity.this, editProfileActivity.class);
                startActivity(aintent);
            }
        });

        editWeight = findViewById(R.id.editWeight);
        editWeight.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent bintent = new Intent(profileActivity.this, editWeightActivity.class);
                startActivity(bintent);
            }
        });

        nav = findViewById(R.id.nav);
        nav.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent cintent = new Intent(profileActivity.this, mainNavActivity.class);
                startActivity(cintent);
            }
        });
    }

}